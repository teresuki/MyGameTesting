#ifndef RENPYBIDICORE_H
#define RENPYBIDICORE_H
#include <Python.h>

PyObject *renpybidi_log2vis(PyUnicodeObject *s, int *direction);
#endif
