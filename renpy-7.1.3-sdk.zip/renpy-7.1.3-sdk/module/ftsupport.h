#ifndef FTSUPPORT_H
#define FTSUPPORT_H
char *freetype_error_to_string(int error);
#endif
